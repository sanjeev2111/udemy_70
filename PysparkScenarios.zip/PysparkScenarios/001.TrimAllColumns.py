# Databricks notebook source


df =  (spark.read.format("csv")
        .option("path","dbfs:/FileStore/tables/Orders.csv")
        .option("header","True").option("inferSchema","True")
        .load())

# COMMAND ----------

from pyspark.sql.functions import trim, col

dfnew = df.select([
    trim(col(c)).alias(c) if dtype == 'string' else col(c)
    for c, dtype in df.dtypes
])


# COMMAND ----------

from pyspark.sql.functions import lower, col

# Convert string columns to lowercase
df_new = df.select([
    lower(col(c)).alias(c) if dtype == 'string' else col(c)
    for c, dtype in df.dtypes
])


# COMMAND ----------

display(df_new)

# COMMAND ----------

