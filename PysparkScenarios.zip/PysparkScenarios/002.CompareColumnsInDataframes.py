# Databricks notebook source
schema = "id int, name string,city string,salary int,phone string"
data = [(1,'John','nyc',10000,'1999-929-192')]
source_df = spark.createDataFrame(data=data,schema=schema)


# COMMAND ----------

target_df =  (spark.read.format("csv")
        .option("path","dbfs:/FileStore/tables/Employees.csv")
        .option("header","True").option("inferSchema","True")
        .load())

# COMMAND ----------

missing_cols_in_target = set(source_df.columns) - set(target_df.columns)
print(f"Missing columns in Target: {missing_cols_in_target}") 

# COMMAND ----------

missing_cols_in_source = set(target_df.columns) - set(source_df.columns)
print(f"Missing columns in Source: {missing_cols_in_source}") 

# COMMAND ----------

def findMissingColumns(source_df,target_df):
    missing_cols = set(source_df.columns) - set(target_df.columns)
    return missing_cols

# COMMAND ----------

findMissingColumns(source_df,target_df)

# COMMAND ----------

findMissingColumns(target_df,source_df)

# COMMAND ----------

