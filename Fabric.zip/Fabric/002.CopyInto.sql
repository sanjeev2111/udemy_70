CREATE TABLE Orders(
    OrderId int,
    ProductKey int,
    Country VARCHAR(50),
    ProductName VARCHAR(100),
    SalesAmount FLOAT,
    TaxAmount FLOAT

)

COPY INTO  Orders
(OrderId,ProductKey,Country,ProductName,SalesAmount,TaxAmount)
FROM 'https://myadlstraining.dfs.core.windows.net/mycontainer/Orders.csv'
WITH
(
    FILE_TYPE='CSV',
    FIRSTROW = 2
)


SELECT * from Orders

CREATE TABLE Orders2(
    InvoiceId int,
    ProductKey int,
    Country VARCHAR(50),
    ProductName VARCHAR(100),
    SalesAmount FLOAT,
    TaxAmount FLOAT

)

COPY INTO  Orders2
(InvoiceId,ProductKey,Country,ProductName,SalesAmount,TaxAmount)
FROM 'https://myadlstraining.dfs.core.windows.net/mycontainer/Orders.parquet'
WITH
(
    FILE_TYPE='PARQUET'
)

SELECT * from Orders2