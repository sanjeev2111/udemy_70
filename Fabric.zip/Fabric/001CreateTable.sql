CREATE TABLE EMPLOYEES(
	EmployeeId int, 
	EmployeeName varchar(40),
	Salary float
)

INSERT INTO EMPLOYEES(EmployeeId,EmployeeName,Salary) VALUES
(1,'AJAY',2000);

INSERT INTO EMPLOYEES(EmployeeId,EmployeeName,Salary) VALUES
(2,'JOHN',3000);


INSERT INTO EMPLOYEES(EmployeeId,EmployeeName,Salary) VALUES
(3,'RAJ',2000);

select * from EMPLOYEES

CREATE TABLE EMPLOYEES2(
	EmployeeId int primary key, 
	EmployeeName varchar(40),
	Salary float
)

